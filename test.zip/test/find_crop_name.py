import pandas as pd

#note que en ./CNA2014_S6CUL_2013_25.csv se eliminaron columnas no útiles 
#y se renombraron para más fácil manejo
data = pd.read_csv('./CNA2014_S6CUL_2013_25.csv')
print(data)
print()

#lee el archivo csv que contiene las equivlencias entre el código y 
#el nombre del cultivo (ese fue hecho a mano a partir del glosario 
#que está online para esa base de datos)
names_eqv = pd.read_csv('./equivalencias_cultivos_code.csv')

print("llaves del dataframe: \n")
print(data.keys())
print()

print("llaves del dataframe de equivalencias de nombre de cultivos:\n")
print(names_eqv.keys())
print()

#aquí ocurre la magia, es como un inner join de sql, para más informacíon leer el último
#comentario
result = pd.merge(data, names_eqv, how='inner', on='cultivo_id')

#cambio de orden de las columnas en la tabla 
#se posiciona la columna nombre al lado de la cultivo_id
name_column = result.pop('nombre')
result.insert(list(result.keys()).index('cultivo_id')+1, 'nombre', name_column)
print(result.head())

result.to_csv('2013_cundinamarca.csv', index=False)

#documentación sobre como hacer un merge e inner join de dataframes en pandas
#1) https://chrisalbon.com/python/data_wrangling/pandas_join_merge_dataframe/


